Screenshot of Dashboards
